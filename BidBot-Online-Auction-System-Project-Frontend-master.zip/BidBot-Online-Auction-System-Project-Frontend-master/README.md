This folder contains the Frontend code for the Online Auction System Website made using Mern stack

The frontend is deployed on render.com

See it live at : https://bidbotauctionsystem.onrender.com

Copyright Hriday Sehgal 2023 All rights reserved. No part of this repository, including but not limited to its code, files, and documentation, may be reproduced, distributed, or transmitted in any form or by any means, including photocopying, recording, or other electronic or mechanical methods, without the prior written permission of the copyright holder, except in the case of brief quotations embodied in critical reviews and certain other noncommercial uses permitted by copyright law.

Unauthorized use, reproduction, distribution, or transmission of this repository's contents is strictly prohibited and may result in legal action.

For inquiries regarding permissions, please contact hriday.career@gmail.com.
